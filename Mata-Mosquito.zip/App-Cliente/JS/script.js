document.addEventListener("DOMContentLoaded", function () {

    // ==========================================
    // ELEMENTOS
    // ==========================================

    const videoElement =
        document.querySelector(".input_video");

    const canvasElement =
        document.querySelector(".webcam_canvas");

    const imgMosquito =
        document.querySelector(".img-mosquito");

    const vidasElemento =
        document.querySelector("#vidas");

    const pontuacaoElemento =
        document.querySelector("#pontuacao");

    const recordeElemento =
        document.querySelector("#recorde-atual");


    // ==========================================
    // VARIÁVEIS DO JOGO
    // ==========================================

    let vidas = 3;

    let pontuacao = 0;

    let jogoAtivo = true;

    let maoEstavaFechada = false;

    let mosquitoFoiAcertado = false;


    // ==========================================
    // RECORD
    // ==========================================

    let recorde =
        Number(localStorage.getItem("recordeMosquito")) || 0;


    recordeElemento.textContent = recorde;


    // ==========================================
    // CANVAS
    // ==========================================

    const canvasCtx =
        canvasElement.getContext("2d");


    function redimensionarCanvas() {

        canvasElement.width =
            window.innerWidth;

        canvasElement.height =
            window.innerHeight;
    }


    window.addEventListener(
        "resize",
        redimensionarCanvas
    );


    redimensionarCanvas();


    // ==========================================
    // MÃO FECHADA
    // ==========================================

    function isMaoFechada(landmarks) {

        const tips = [8, 12, 16, 20];

        const mcps = [5, 9, 13, 17];

        let dedosDobrados = 0;


        for (let i = 0; i < 4; i++) {

            const tip =
                landmarks[tips[i]];

            const mcp =
                landmarks[mcps[i]];


            const distanciaTip =
                Math.hypot(
                    tip.x - landmarks[0].x,
                    tip.y - landmarks[0].y
                );


            const distanciaMcp =
                Math.hypot(
                    mcp.x - landmarks[0].x,
                    mcp.y - landmarks[0].y
                );


            if (distanciaTip < distanciaMcp) {

                dedosDobrados++;
            }
        }


        return dedosDobrados >= 3;
    }


    // ==========================================
    // ACERTOU MOSQUITO
    // ==========================================

    function acertouMosquito() {

        if (!jogoAtivo) {
            return;
        }


        // Evita contar o mesmo mosquito duas vezes

        if (mosquitoFoiAcertado) {
            return;
        }


        mosquitoFoiAcertado = true;


        // +10 pontos

        pontuacao += 10;


        pontuacaoElemento.textContent =
            pontuacao;


        // Atualizar recorde

        if (pontuacao > recorde) {

            recorde = pontuacao;

            recordeElemento.textContent =
                recorde;

            localStorage.setItem(
                "recordeMosquito",
                recorde
            );
        }


        // Mudar mosquito

        mudarPosicaoMosquito();
    }


    // ==========================================
    // MOVER MOSQUITO
    // ==========================================

    function mudarPosicaoMosquito() {

        const largura =
            window.innerWidth - 120;

        const altura =
            window.innerHeight - 120;


        const novaX =
            Math.floor(
                Math.random() * Math.max(largura, 1)
            );


        const novaY =
            Math.floor(
                Math.random() * Math.max(altura, 1)
            );


        imgMosquito.style.left =
            novaX + "px";

        imgMosquito.style.top =
            novaY + "px";


        mosquitoFoiAcertado = false;
    }


    // ==========================================
    // CLIQUE DO MOUSE
    // ==========================================

    imgMosquito.addEventListener(
        "click",
        function () {

            acertouMosquito();

        }
    );


    // ==========================================
    // PERDER VIDA
    // ==========================================

    function perderVida() {

        if (!jogoAtivo) {
            return;
        }


        vidas--;


        vidasElemento.textContent =
            vidas;


        if (vidas <= 0) {

            fimDeJogo();
        }
    }


    // ==========================================
    // GAME OVER
    // ==========================================

    function fimDeJogo() {

        jogoAtivo = false;


        imgMosquito.style.display =
            "none";


        const telaGameOver =
            document.createElement("div");


        telaGameOver.classList.add(
            "game-over"
        );


        let textoRecorde = "";


        if (pontuacao === recorde &&
            pontuacao > 0) {

            textoRecorde = `
                <div class="novo-recorde">
                    ⭐ NOVO RECORDE! ⭐
                </div>
            `;
        }


        telaGameOver.innerHTML = `

            <h1>GAME OVER</h1>

            <p>
                Pontuação:
                <strong>${pontuacao}</strong>
            </p>

            ${textoRecorde}

            <button onclick="location.reload()">
                Jogar Novamente
            </button>
        `;


        document.body.appendChild(
            telaGameOver
        );
    }


    // ==========================================
    // MEDIAPIPE
    // ==========================================

    if (typeof Hands === "undefined") {

        console.error(
            "MediaPipe Hands não foi carregado."
        );

        return;
    }


    const hands =
        new Hands({

            locateFile: function (file) {

                return (
                    "https://cdn.jsdelivr.net/npm/@mediapipe/hands/" +
                    file
                );
            }

        });


    hands.setOptions({

        maxNumHands: 1,

        modelComplexity: 0,

        minDetectionConfidence: 0.6,

        minTrackingConfidence: 0.6

    });


    // ==========================================
    // RESULTADO DA MÃO
    // ==========================================

    hands.onResults(function (results) {

        canvasCtx.clearRect(
            0,
            0,
            canvasElement.width,
            canvasElement.height
        );


        if (
            !results.multiHandLandmarks ||
            results.multiHandLandmarks.length === 0
        ) {

            maoEstavaFechada = false;

            return;
        }


        const landmarks =
            results.multiHandLandmarks[0];


        const centroMao =
            landmarks[9];


        const x =
            (1 - centroMao.x) *
            canvasElement.width;


        const y =
            centroMao.y *
            canvasElement.height;


        const estaFechada =
            isMaoFechada(landmarks);


        // ==========================================
        // DESENHAR MÃO
        // ==========================================

        canvasCtx.beginPath();


        canvasCtx.arc(
            x,
            y,
            estaFechada ? 35 : 25,
            0,
            2 * Math.PI
        );


        if (estaFechada) {

            canvasCtx.fillStyle =
                "rgba(255, 0, 0, 0.7)";

            canvasCtx.strokeStyle =
                "#ffffff";

        } else {

            canvasCtx.fillStyle =
                "rgba(0, 189, 236, 0.5)";

            canvasCtx.strokeStyle =
                "#00bdec";
        }


        canvasCtx.fill();


        canvasCtx.lineWidth = 4;

        canvasCtx.stroke();


        // ==========================================
        // FECHOU A MÃO
        // ==========================================

        if (
            estaFechada &&
            !maoEstavaFechada &&
            jogoAtivo
        ) {

            const rect =
                imgMosquito.getBoundingClientRect();


            if (
                x >= rect.left &&
                x <= rect.right &&
                y >= rect.top &&
                y <= rect.bottom
            ) {

                acertouMosquito();
            }
        }


        maoEstavaFechada =
            estaFechada;
    });


    // ==========================================
    // INICIAR CÂMERA
    // ==========================================

    async function iniciarCamera() {

        try {

            if (
                !navigator.mediaDevices ||
                !navigator.mediaDevices.getUserMedia
            ) {

                alert(
                    "Seu navegador não permite acesso à câmera."
                );

                return;
            }


            const stream =
                await navigator.mediaDevices.getUserMedia({

                    video: {

                        width: {
                            ideal: 640
                        },

                        height: {
                            ideal: 480
                        },

                        facingMode: "user"

                    },

                    audio: false
                });


            videoElement.srcObject =
                stream;


            await videoElement.play();


            console.log(
                "Câmera iniciada!"
            );


            // ==========================================
            // PROCESSAR CÂMERA
            // ==========================================

            async function processarCamera() {

                if (
                    videoElement.readyState >= 2 &&
                    !videoElement.paused
                ) {

                    try {

                        await hands.send({
                            image: videoElement
                        });

                    } catch (erro) {

                        console.error(
                            "Erro no processamento:",
                            erro
                        );
                    }
                }


                if (jogoAtivo) {

                    requestAnimationFrame(
                        processarCamera
                    );
                }
            }


            processarCamera();


        } catch (erro) {

            console.error(
                "Erro ao acessar câmera:",
                erro
            );


            if (
                erro.name ===
                "NotAllowedError"
            ) {

                alert(
                    "A câmera foi bloqueada. " +
                    "Clique no cadeado ao lado do endereço do site " +
                    "e permita o uso da câmera."
                );

            } else {

                alert(
                    "Não foi possível iniciar a câmera."
                );
            }
        }
    }


    // ==========================================
    // INÍCIO DO JOGO
    // ==========================================

    mudarPosicaoMosquito();


    // A cada segundo verifica se o mosquito
    // escapou

    setInterval(function () {

        if (!jogoAtivo) {
            return;
        }


        if (!mosquitoFoiAcertado) {

            perderVida();

        }


        if (jogoAtivo) {

            mudarPosicaoMosquito();
        }

    }, 1000);


    // ==========================================
    // COMEÇAR CÂMERA
    // ==========================================

    iniciarCamera();

});