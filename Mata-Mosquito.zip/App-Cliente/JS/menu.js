// ==============================
// SELEÇÃO DE DIFICULDADE
// ==============================

const itensDificuldade = document.querySelectorAll("#lista-dificuldade li");
const btnJogar = document.getElementById("btn-jogar");

let nivelSelecionado = "baby"; // valor padrão

itensDificuldade.forEach(function (item) {
    item.addEventListener("click", function () {
        // tira a seleção de todos
        itensDificuldade.forEach(function (i) {
            i.classList.remove("selecionado");
        });

        // marca só o que foi clicado
        item.classList.add("selecionado");

        // guarda o nível escolhido
        nivelSelecionado = item.dataset.nivel;

        // atualiza o link do botão Jogar
        btnJogar.href = "Baby.html?nivel=" + nivelSelecionado;
    });
});